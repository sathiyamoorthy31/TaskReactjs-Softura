import React, { useState } from 'react';
import { Route, Switch } from "react-router-dom";
import AdminForm from './Pages/AdminForm.component';
import ViewGrid from './Pages/ViewGrid.component';
import { Button } from '@material-ui/core';
import './Pages/style.scss';
const Routing = ({ history }) => {
    const [data, setData] = useState([]);
    const [save, setSave] = useState(false);
    let url = window.location.href.includes("adminform");
    const updateGrid = (gridData) => {
        let sample = [...data];
        sample.push(gridData);
        setData(sample);
        setSave(true);
    }
    const naviageForm = (e,name) => {
        debugger
        e.currentTarget.classList.add("active");
        if (name === "form") {
            document.getElementById("grid").classList.remove("active");
            history.push({
                pathname: '/adminform',
            });
        }
        else {
            document.getElementById("admin").classList.remove("active");
            history.push({
                pathname: '/viewgrid',
                data
            });
        }

    }
    return (
        <React.Fragment>
            <div className="">
            <div className="header-group">
                <Button id="admin" className={url && "active"} variant="contained" onClick={(e) => naviageForm(e,"form")}>
                    Admin Form
            </Button >
                <Button id="grid" className={!url && "active"} variant="contained" onClick={(e) => naviageForm(e,"grid")}>
                    View Grid
            </Button>
            </div>
            <div className="route">
                <Switch>
                    <Route path='/adminform' render={(props) => <AdminForm updateGrid={updateGrid} save={save}{...props} />} />
                    <Route path='/viewgrid' render={(props) => <ViewGrid history={history} {...props} />} />
                </Switch>
            </div>
            </div>
        </React.Fragment>
    );


}


export default Routing;
