import React from 'react';
import { ADMIN_FORM } from '../Constant.js';
import GenericForm from '../Components/Form/generic-form.component';
const AdminForm = ({updateGrid}) => {
    return (
        <div>
            <div className="admin">
                <div className="pageHeader">
                    <div className="formTitle">Admin Form</div>
                </div>
                <div className="pageBody">
                    <GenericForm field={ADMIN_FORM} updateGrid={updateGrid} />
                </div>
            </div>
        </div>
    );
}

export default AdminForm;