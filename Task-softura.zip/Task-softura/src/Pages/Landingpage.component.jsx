import React,{useState}from 'react';
import './style.scss';
import {ADMIN_FORM} from '../Constant.js';
import GenericForm from '../Components/Form/generic-form.component';
import CustomTable from '../Components/Table/table.component';
//For Future use Landing Page includes both admin form and view grid
const Landing = () => {
    const [data,setData] = useState({});
    const pullData = (data) => {
       setData(data);
    }
    return(
        <div>
            
        <div className="admin">
            <div className="pageHeader">
                <div className="formTitle">Admin Form</div>
            </div>
            <div className="pageBody">
             <GenericForm field={ADMIN_FORM} handleSubmit={pullData}/>
           </div>
        </div>
        <CustomTable value={data}/>
        </div>
    );
}

export default Landing;