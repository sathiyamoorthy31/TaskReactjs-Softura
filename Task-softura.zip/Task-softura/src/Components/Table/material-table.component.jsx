import React, { useEffect, useState } from 'react';
import MaterialTable from "material-table";
import DownloadForOfflineIcon from '@mui/icons-material/DownloadForOffline';
const CustomTable = (props) => {
    const [tableData, setTableData] = useState([]);
    useEffect(() => {
        setTableData(props.gridData.location.data);
    }, [props.gridData.location.data])
    const ViewGrid_Header = [
            { title: "Project Name", field: "projectname" },
            
            { title: "Priority(p1,p2,p3)", field: "priority" },
            { title: "Hours Need", field: "hours" },
            { title: "Start Date", field: "startdate" },
            { title: "End Date", field: "enddate" },
            { title: "Resource Type", field: "resourcetype" },
            { title: "Task Type", field: "tasktype" },
           {
              title: "Download",
              field: "attachment",
              render: rowData => rowData.file && <a download href={rowData.file}><DownloadForOfflineIcon /></a>
            },
          ]
    return(
        <div className="materialTable">
        <MaterialTable
          columns={ViewGrid_Header}
          data={tableData}
          title="View Grid"
        />
      </div>
    );
}

export default CustomTable;