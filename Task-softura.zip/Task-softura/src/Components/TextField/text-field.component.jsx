import React from 'react'
import { TextField } from '@material-ui/core';
const InputField = (props) => {
    const { name, label, handleChange, value } = props;

    console.log("textfield");
    return (
        <TextField
            variant="outlined"
            fullWidth
            id={name}
            name={name}
            label={label}
            value={value}
            onChange={handleChange}
            size="small"
            placeholder={label.replace(/[*]/g, '')}
            InputLabelProps={{
                shrink: true
            }}
        />

    );
}

export default React.memo(InputField)