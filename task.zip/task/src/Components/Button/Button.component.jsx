import Button from '@material-ui/core/Button';
import './Button.style.scss';
const TextButton = (props) =>{
    return(
        <Button variant="contained" className={props.class} color="inherit">
            {props.name}
        </Button>   
    );
}

export default TextButton;