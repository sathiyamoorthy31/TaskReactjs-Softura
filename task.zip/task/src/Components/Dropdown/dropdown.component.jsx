import React from 'react';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';


const Dropdown = ({ field, value, handleChange }) => {
    return (
        <FormControl fullWidth>
            <InputLabel id="demo-simple-select-label">{field.label}</InputLabel>
            <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={value}
                defaultValue={field.placeholder}
                name={field.name}
                label={field.label}
                onChange={handleChange}
                variant="outlined"
                size="small"
            >
            <MenuItem key={field.placeholder} value={field.placeholder}>{field.placeholder}</MenuItem>
                {field.reference.map((ref, index) => {
                    return (
                        <MenuItem key={index} value={ref}>{ref}</MenuItem>
                    );
                })}

            </Select>
        </FormControl>
    );
}

export default Dropdown;