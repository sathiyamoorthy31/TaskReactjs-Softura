import React, { useEffect, useState } from 'react';
import { GRID_HEAD } from '../../Constant'
const CustomTable = (props) => {
    const [tableData, setTableData] = useState([]);
    useEffect(() => {
        setTableData(props.gridData.location.data);
    }, [props.gridData.location.data])
    debugger;
    return (
        <div className="custom-table">
            <table>
                <thead>
                    <tr>
                        {GRID_HEAD.map((head) => {
                            return (
                                <th>{head}</th>
                            );
                        })}

                    </tr>
                </thead>
                <tbody>

                    {tableData.map((res) => {
                        return (
                            <tr>
                                <td>{res.projectname ? res.projectname : "-"}</td>
                                <td>{res.priority ? res.priority : "-"}</td>
                                <td>{res.hours ? res.hours : "-"}</td>
                                <td>{res.startdate ? res.startdate : "-"}</td>
                                <td>{res.enddate ? res.enddate : "-"}</td>
                                <td>{res.resourcetype ? res.resourcetype : "-"}</td>
                                <td>{res.tasktype ? res.tasktype : "-"}</td>
                            </tr>
                        );

                    })}

                </tbody>
            </table>
        </div>
    );
}

export default CustomTable;