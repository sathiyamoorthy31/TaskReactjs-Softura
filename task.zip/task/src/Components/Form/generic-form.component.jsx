import React, {useState } from 'react';
import { Grid, Button } from '@material-ui/core';
import { ADMIN_FORM } from '../../Constant';
import TextField from '../TextField/text-field.component';
import Dropdown from '../Dropdown/dropdown.component';
import { makeStyles } from '@material-ui/core/styles';
import Alert from '@material-ui/lab/Alert';
import DatePicker from '../DatePicker/DatePicker.component';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        '& > * + *': {
            marginTop: theme.spacing(2),
        },
    },
}));
const GenericForm = (props) => {
    const classes = useStyles();
    const [form, setForm] = useState({});
    const [fail, setFail] = useState(false);
    const handleChange = (e) => {
        setForm({
            ...form, [e.target.name]: e.target.value
        })
        setFail(false);
    }
    const dateChange = (e, name) => {
        var n = e && e.toLocaleDateString();
        setForm({
            ...form, [name]: n
        })
        setFail(false);
    }
    const handleForm = (fields) => {
        switch (fields.type) {
            case "text":
                return <Grid item xs={12} sm={4} md={4} lg={4} xl={4}>
                    <TextField
                        id={fields.label}
                        name={fields.name}
                        label={fields.label}
                        value={form[fields.name]}
                        placeholder={fields.placeholder}
                        handleChange={handleChange}
                    />
                </Grid>
            case "dropdown":
                return <Grid item className={fields.name} xs={12} sm={4} md={4} lg={4} xl={4}>
                    <Dropdown field={fields} handleChange={handleChange} value={form[fields.name]} />
                </Grid>
            case "datepicker":
                return <Grid className="date-picker" item xs={12} sm={4} md={4} lg={4} xl={4}>
                    <DatePicker field={fields} dateChange={dateChange} values={form[fields.name]} />
                </Grid>
            default : 
              return null;
        }
    }
    const saveForm = () =>{
        props.updateGrid(form);
        setFail(true);
    }
    return (
        <div>
            <Grid container spacing={2}>
                {
                    ADMIN_FORM.map(field => {
                        return (
                            handleForm(field)
                        );
                    })
                }
            </Grid>
            <Grid item xs={12} sm={12} md={12}>
                <Button variant="contained" type="button" className="save-button pointer" onClick={saveForm} color="inherit">
                    Save
                    </Button>
               
                {fail && <div className={classes.root}>
                    <Alert severity="success">Form Saved Successfully</Alert>
                </div>}

            </Grid>
        </div>
    );
}

export default GenericForm;