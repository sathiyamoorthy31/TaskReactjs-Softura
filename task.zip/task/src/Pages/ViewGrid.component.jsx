import React from 'react';
import CustomTable from '../Components/Table/table.component';
const ViewGrid = (props) => {
    return(
        <div className="viewGrid">
            <CustomTable gridData={props}/>
        </div>
    );
}

export default ViewGrid;