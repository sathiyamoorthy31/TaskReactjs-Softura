import React,{useState}from 'react';
import './style.scss';
import {ADMIN_FORM} from '../Constant.js';
import GenericForm from '../Components/Form/generic-form.component';
import CustomTable from '../Components/Table/table.component';

const Landing = () => {
    const [data,setData] = useState({});
    const pullData = (data) => {
        // alert("sathiya");
        console.log("sathiyamoorthy visvanathan");
        console.log(JSON.stringify(data));
        setData(data);
    }
    return(
        <div>
            
        <div className="admin">
            <div className="pageHeader">
                <div className="formTitle">Admin Form</div>
            </div>
            <div className="pageBody">
             <GenericForm field={ADMIN_FORM} handleSubmit={pullData}/>
           </div>
        </div>
        <CustomTable value={data}/>
        </div>
    );
}

export default Landing;