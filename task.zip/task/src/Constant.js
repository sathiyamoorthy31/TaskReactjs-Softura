export const ADMIN_FORM = [
    {
        label : "Project Name",
        type : "dropdown",
        placeholder: "Select Project Name",
        name:"projectname",
        reference : ["Livonio LTD","Adro CTP","Anion KCT","Live Archs PCPs"]
    },
    {
        label : "Priority",
        type : "dropdown",
        placeholder: "Select Priority",
        name:"priority",
        reference: ["p1","p2","p3"]
    },
    {
        label : "Hours",
        type : "text",
        placeholder: "Enter Hours",
        name:"hours"
    },
    {
        label : "Resource Type",
        type : "dropdown",
        placeholder: "Select Resource Type",
        name:"resourcetype",
        reference: ["WireFrame","HTML Conversion","Bugs","WireFrame","Developer Support"]
    },
    {
        label : "Task Type",
        type : "dropdown",
        placeholder: "Select Task Type",
        name:"tasktype",
        reference: ["New Task","Continue Task"]
    },
    {
        label : "Start Date",
        type : "datepicker",
        placeholder: "Start Date",
        name:"startdate"
    },
    {
        label : "End Date",
        type : "datepicker",
        placeholder: "End Date",
        name:"enddate"
    },
    {
        label : "Attachment",
        type : "file",
        placeholder: "Attachment",
        name:"attachment"
    }
];
export const GRID_HEAD = ['PROJECT NAME','PRIORITY(P1,P2,P3)','HOURS NEED','START DATE','END DATE','RESOURCE TYPE','TASK TYPE']