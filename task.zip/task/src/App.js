import React from 'react';
import './App.css';
import Routing from '../src/route';
import {useHistory} from 'react-router-dom';
const App = () =>{
  const history = useHistory();
  
  return (
    <div className="app-root">
      <Routing history={history}/>
    </div>
  );
}

export default App;
